package object;


import entity.Entity;
import main.Gamepanel;

public class OBJ_Door extends Entity{

	
	public OBJ_Door(Gamepanel gp) {
		super(gp);
		name = "Door";
		down1 = setup("/objects/door",gp.tilesize, gp.tilesize);
		collision = true;
		
		solidarea.x = 0;
		solidarea.y = 16;
		solidarea.width = 48;
		solidarea.height = 32;
		solidAreaDefaultx = solidarea.x;
		solidAreaDefaulty = solidarea.y;
	}
}
