package object;



import entity.Entity;
import main.Gamepanel;

public class OBJ_Heart extends Entity {
	
	
	public OBJ_Heart(Gamepanel gp) {
		super(gp);        
        name = "Heart";
        image = setup("/objects/heart_full",gp.tilesize, gp.tilesize);
        image2 = setup("/objects/heart_half",gp.tilesize, gp.tilesize);
        image3 = setup("/objects/heart_blank",gp.tilesize, gp.tilesize);
    }
}