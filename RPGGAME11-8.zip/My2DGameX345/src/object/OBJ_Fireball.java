package object;

import entity.Projectile;
import main.Gamepanel;

public class OBJ_Fireball extends Projectile {
	Gamepanel gp;

	public OBJ_Fireball(Gamepanel gp) {
		super(gp);
		this.gp = gp;
		name = "Fireball";
		speed = 5;
		maxLife = 80;
		life = maxLife;
		attack = 2;
		useCost = 1;
		alive = false;
		getImage();
		// TODO Auto-generated constructor stub
	}
	public void getImage() {
		up1 = setup("/projectile/fireball_up_1",gp.tilesize,gp.tilesize);
		up2 = setup("/projectile/fireball_up_2",gp.tilesize,gp.tilesize);
		down1 = setup("/projectile/fireball_down_1",gp.tilesize,gp.tilesize);
		down2 = setup("/projectile/fireball_down_2",gp.tilesize,gp.tilesize);
		left1 = setup("/projectile/fireball_left_1",gp.tilesize,gp.tilesize);
		left2 = setup("/projectile/fireball_left_2",gp.tilesize,gp.tilesize);
		right1 = setup("/projectile/fireball_right_1",gp.tilesize,gp.tilesize);
		right2 = setup("/projectile/fireball_right_2",gp.tilesize,gp.tilesize);
		
	}

}
