package object;



import entity.Entity;
import main.Gamepanel;

public class OBJ_Chest extends Entity {
	
	public OBJ_Chest(Gamepanel gp) {
		super(gp);
        name = "Chest";
        down1 = setup("/objects/chest",gp.tilesize, gp.tilesize);
    }
}
