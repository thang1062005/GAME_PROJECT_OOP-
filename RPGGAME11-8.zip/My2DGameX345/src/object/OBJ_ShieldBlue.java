package object;

import entity.Entity;
import main.Gamepanel;

public class OBJ_ShieldBlue extends Entity {
	public OBJ_ShieldBlue(Gamepanel gp) {
		super(gp);
		type = type_shield;
		name = "Blue Shield";
		down1 = setup("/objects/shield_blue", gp.tilesize, gp.tilesize);
		defenseValue = 1;
		description = "[" + name + "]\na blue shield";
	}
}


