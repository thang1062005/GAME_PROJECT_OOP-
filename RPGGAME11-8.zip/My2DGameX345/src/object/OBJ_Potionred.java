package object;

import entity.Entity;
import main.Gamepanel;

public class OBJ_Potionred extends Entity {
	Gamepanel gp;
	int value = 5;

	public OBJ_Potionred(Gamepanel gp) {
		super(gp);
		this.gp =gp;
		type = type_consumable;
		name = "Red Potion";
		down1 = setup("/objects/potion_red", gp.tilesize, gp.tilesize);

		description = "[" + name + "]\nheal yourself 5";
		// TODO Auto-generated constructor stub
	}
	public void use(Entity entity) {
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You drank the"+name+"!\n"
				+ "Recover your HP by"+value;
		entity.life += value;
		if (gp.player.life> gp.player.maxLife) {
			gp.player.life = gp.player.maxLife;
			
		}
		gp.playSE(2);
		
	}
	

}
