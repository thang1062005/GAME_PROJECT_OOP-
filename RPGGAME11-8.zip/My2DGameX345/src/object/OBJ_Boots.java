package object;


import entity.Entity;
import main.Gamepanel;


public class OBJ_Boots extends Entity{

	public OBJ_Boots(Gamepanel gp) {
		super(gp);
		name = "Boots";
		down1 = setup("/objects/boots",gp.tilesize, gp.tilesize);
	}
}
