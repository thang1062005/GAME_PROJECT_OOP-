package object;

import entity.Entity;
import main.Gamepanel;

public class OBJ_Axe extends Entity {

	public OBJ_Axe(Gamepanel gp) {
		super(gp);
		// TODO Auto-generated constructor stub
		type = type_axe;
		name = "Woodcutter's Axe";
		down1 = setup("/objects/axe",gp.tilesize,gp.tilesize);
		attackValue = 2;
		attackArea.width = 30;
		attackArea.height = 30;
		description = "[" + name + "]\nrusty but usable";
		
	}

}
