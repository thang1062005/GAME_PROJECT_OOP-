package monster;

import java.util.Random;

import entity.Entity;
import main.Gamepanel;

public class MON_GreenSlime extends Entity{
	Gamepanel gp;

	public MON_GreenSlime(Gamepanel gp) {
		super(gp);
		this.gp = gp;
		
		type = type_monster;
		name = "Green Slime";
		speed = 1;
		maxLife = 4;
		life = maxLife;
		attack = 2;
		defense = 0;
		exp = 1;
		
		solidarea.x = 3;
		solidarea.y = 10;
		solidarea.width = 42;
		solidarea.height = 30;
		solidAreaDefaultx = solidarea.x;
		solidAreaDefaulty = solidarea.y;
		
		getImage();
	}
	public void getImage() {
		
		up1 = setup("/monster/greenslime_down_1",gp.tilesize, gp.tilesize);
		up2 = setup("/monster/greenslime_down_2",gp.tilesize, gp.tilesize);
		down1 = setup("/monster/greenslime_down_1",gp.tilesize, gp.tilesize);
		down2 = setup("/monster/greenslime_down_2",gp.tilesize, gp.tilesize);
		left1 = setup("/monster/greenslime_down_1",gp.tilesize, gp.tilesize);
		left2 = setup("/monster/greenslime_down_2",gp.tilesize, gp.tilesize);
		right1 = setup("/monster/greenslime_down_1",gp.tilesize, gp.tilesize);
		right2 = setup("/monster/greenslime_down_2",gp.tilesize, gp.tilesize);
	}
	public void setAction() {
		actionLock++;
		
		if(actionLock == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1;	//pick up a number from 1 to 100
			
			if(i <= 25) {
				direction = "up";
			}
			if(i > 25 && i <= 50) {
				direction = "down";
			}
			if(i > 50 && i <= 75) {
				direction = "left";
			}
			if(i > 75 && i <= 100) {
				direction = "right";
			}
			
			actionLock = 0;
		}
	}
	
	public void damageReaction() {
		actionLock = 0;
		direction = gp.player.direction;
	}
}
