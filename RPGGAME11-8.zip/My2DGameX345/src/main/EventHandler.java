package main;

  

public class EventHandler {

	Gamepanel gp;
	EventRect eventRect [][];
	
	public EventHandler(Gamepanel gp) {
		this.gp = gp;
		
		eventRect = new EventRect[gp.maxworldcol][gp.maxworldrow];
		
		int col = 0;
		int row = 0;
		while (col < gp.maxworldcol && row < gp.maxworldrow) {		
			eventRect[col][row] = new EventRect();
			eventRect[col][row].x = 23;
			eventRect[col][row].y = 23;
			eventRect[col][row].width = 2;
			eventRect[col][row].height = 2;
			eventRect[col][row].eventRectDefaultX = eventRect[col][row].x;
			eventRect[col][row].eventRectDefaultY = eventRect[col][row].y;
			
			col++;
			if(col == gp.maxworldcol) {
				col = 0;
				row++;
				}
			}
		}
		
	
	public void checkEvent() {
		
		if (hit(10,7,"up") == true) {
			damagePit(10,7,gp.dialogueState);
		}
		if (hit(23,9,"up") == true) {
			healingPool(23,9,gp.dialogueState);
		}
	}
	public boolean hit(int col, int row, String reqDirection) {
		boolean hit = false;
		
		gp.player.solidarea.x = gp.player.worldx +  gp.player.solidarea.x;
		gp.player.solidarea.y = gp.player.worldy +  gp.player.solidarea.y;
		eventRect[col][row].x = col*gp.tilesize + eventRect[col][row].x;
		eventRect[col][row].y = row*gp.tilesize + eventRect[col][row].y;
		
		if(gp.player.solidarea.intersects(eventRect[col][row]) && eventRect[col][row].eventDone == false) {
			if(gp.player.direction.contentEquals(reqDirection) || reqDirection.contentEquals("any")) {
				hit = true;
			}
		}
		gp.player.solidarea.x = gp.player.solidAreaDefaultx;
		gp.player.solidarea.y = gp.player.solidAreaDefaulty;
		eventRect[col][row].x = eventRect[col][row].eventRectDefaultX;
		eventRect[col][row].y = eventRect[col][row].eventRectDefaultY;
		
		return hit;
	}
	public void damagePit(int col, int row, int gameState) {
		
		gp.gameState = gameState;
		gp.playSE(6);
		gp.ui.currentDialogue = "You fall into a pit!";
		gp.player.life -=1;
		eventRect[col][row].eventDone = true;
	}
	public void healingPool(int col, int row, int gameState) {
		if (gp.keyH.enterPressed == true) {
			gp.gameState = gameState;
			gp.player.attackCancel = true;
			gp.playSE(2);
			gp.ui.currentDialogue = "You drink the water.\nYour life has been recovered.";
			gp.player.life = gp.player.maxLife;
			gp.aSetter.setMonster();
		}
	}
	
}
