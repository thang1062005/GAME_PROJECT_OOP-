package main;

import entity.NPC_Oldman;
import monster.MON_GreenSlime;
import object.OBJ_Axe;
import object.OBJ_Key;
import object.OBJ_Potionred;
import object.OBJ_ShieldBlue;
public class AssetSetter {

	Gamepanel gp;

	public AssetSetter(Gamepanel gp) {

		this.gp = gp ;

	}

	public void setObject() {
		int i = 0;
		gp.obj[i] = new OBJ_Key(gp);
		gp.obj[i].worldx = gp.tilesize*25;
		gp.obj[i].worldy = gp.tilesize*23;
		i++;
		gp.obj[i] = new OBJ_Key(gp);
		gp.obj[i].worldx = gp.tilesize*21;
		gp.obj[i].worldy = gp.tilesize*19;
		i++;
		gp.obj[i] = new OBJ_Key(gp);
		gp.obj[i].worldx = gp.tilesize*26;
		gp.obj[i].worldy = gp.tilesize*21;
		i++;
		
		gp.obj[i] = new OBJ_Axe(gp);
		gp.obj[i].worldx = gp.tilesize*33;
		gp.obj[i].worldy = gp.tilesize*21;
		i++;
		gp.obj[i] = new OBJ_ShieldBlue(gp);
		gp.obj[i].worldx = gp.tilesize*35;
		gp.obj[i].worldy = gp.tilesize*21;
		i++;
		gp.obj[i] = new OBJ_Potionred(gp);
		gp.obj[i].worldx = gp.tilesize*22;
		gp.obj[i].worldy = gp.tilesize*27;
		i++;
	}
	
	public void setNPC() {
		gp.npc[0] = new NPC_Oldman(gp);
		gp.npc[0].worldx = gp.tilesize*21;
		gp.npc[0].worldy = gp.tilesize*21;
		
//		gp.npc[0] = new NPC_Oldman(gp);
//		gp.npc[0].worldx = gp.tilesize*9;
//		gp.npc[0].worldy = gp.tilesize*10;

	}
	public void setMonster() {
		int i = 0;
		
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldx = gp.tilesize*21;
		gp.monster[i].worldy = gp.tilesize*38;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldx = gp.tilesize*23;
		gp.monster[i].worldy = gp.tilesize*42;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldx = gp.tilesize*24;
		gp.monster[i].worldy = gp.tilesize*37;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldx = gp.tilesize*34;
		gp.monster[i].worldy = gp.tilesize*42;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldx = gp.tilesize*38;
		gp.monster[i].worldy = gp.tilesize*42;
		i++;
		
		
	}

}