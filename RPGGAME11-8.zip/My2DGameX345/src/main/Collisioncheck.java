package main;

import entity.Entity;


public class Collisioncheck {
    Gamepanel gp;

    public Collisioncheck(Gamepanel gp) {
        this.gp = gp;
    }

    // Method để check va chạm của entity với tiles
    public void CheckTile(Entity entity) {
        int entityleftworldx = entity.worldx + entity.solidarea.x;
        int entityrightwordx = entity.worldx + entity.solidarea.x + entity.solidarea.width;
        int entitytopworldy = entity.worldy + entity.solidarea.y;
        int entitybotworldy = entity.worldy + entity.solidarea.y + entity.solidarea.height;

        int entityleftcol = entityleftworldx / gp.tilesize;
        int entityrightcol = entityrightwordx / gp.tilesize;
        int entitytoprow = entitytopworldy / gp.tilesize;
        int entitybotrow = entitybotworldy / gp.tilesize;

        int tilenum1, tilenum2;
        switch (entity.direction) {
            case "up":
                entitytoprow = (entitytopworldy - entity.speed) / gp.tilesize;
                tilenum1 = gp.tileM.maptilenum[entityleftcol][entitytoprow];
                tilenum2 = gp.tileM.maptilenum[entityrightcol][entitytoprow];
                if (gp.tileM.tile[tilenum1].collision == true || gp.tileM.tile[tilenum2].collision == true) {
                    entity.collisionon = true;
                }
                break;
            case "down":
                entitybotrow = (entitybotworldy + entity.speed) / gp.tilesize;
                tilenum1 = gp.tileM.maptilenum[entityleftcol][entitybotrow];
                tilenum2 = gp.tileM.maptilenum[entityrightcol][entitybotrow];
                if (gp.tileM.tile[tilenum1].collision == true || gp.tileM.tile[tilenum2].collision == true) {
                    entity.collisionon = true;
                }
                break;
            case "left":
                entityleftcol = (entityleftworldx - entity.speed) / gp.tilesize;
                tilenum1 = gp.tileM.maptilenum[entityleftcol][entitytoprow];
                tilenum2 = gp.tileM.maptilenum[entityleftcol][entitybotrow];
                if (gp.tileM.tile[tilenum1].collision == true || gp.tileM.tile[tilenum2].collision == true) {
                    entity.collisionon = true;
                }
                break;
            case "right":
                entityrightcol = (entityrightwordx + entity.speed) / gp.tilesize;
                tilenum1 = gp.tileM.maptilenum[entityrightcol][entitytoprow];
                tilenum2 = gp.tileM.maptilenum[entityrightcol][entitybotrow];
                if (gp.tileM.tile[tilenum1].collision == true || gp.tileM.tile[tilenum2].collision == true) {
                    entity.collisionon = true;
                }
                break;
        }
    }

    // Method để check va chạm của entity với objects
    public int CheckObject(Entity entity, boolean player) {
        int index = 999;
        for (int i = 0; i < gp.obj.length; i++) {
            if (gp.obj[i] != null) {
            	//Get entity's soild area position
            	entity.solidarea.x = entity.worldx + entity.solidarea.x;
            	entity.solidarea.y = entity.worldy + entity.solidarea.y;
            	//Get the object'ssolid area position
            	gp.obj[i].solidarea.x = gp.obj[i].worldx + gp.obj[i].solidarea.x;
            	gp.obj[i].solidarea.y = gp.obj[i].worldy + gp.obj[i].solidarea.y;
            	
            	
                switch (entity.direction) {
                    case "up":entity.solidarea.y -= entity.speed; break;
                    case "down":entity.solidarea.y += entity.speed; break;
                    case "left":entity.solidarea.x -= entity.speed;break;
                    case "right":entity.solidarea.x += entity.speed;break;
                } 
                if (entity.solidarea.intersects(gp.obj[i].solidarea)) {
                    if (gp.obj[i].collision == true) {
                        entity.collisionon = true;
                    }
                    if (player == true) {
                        index = i;
                    }
                }
                // Đặt lại tọa độ gốc của solidArea
                entity.solidarea.x = entity.solidAreaDefaultx;
                entity.solidarea.y = entity.solidAreaDefaulty;
                gp.obj[i].solidarea.x = gp.obj[i].solidAreaDefaultx;
                gp.obj[i].solidarea.y = gp.obj[i].solidAreaDefaulty;
            }
        }
        return index;
    }
    
    //NPC OR MONSTER
    public int checkEntity(Entity entity, Entity[] target) {
    	int index = 999;
        for (int i = 0; i < target.length; i++) {
            if (target[i] != null) {
            	//Get entity's soild area position
            	entity.solidarea.x = entity.worldx + entity.solidarea.x;
            	entity.solidarea.y = entity.worldy + entity.solidarea.y;
            	//Get the object'ssolid area position
            	target[i].solidarea.x = target[i].worldx + target[i].solidarea.x;
            	target[i].solidarea.y = target[i].worldy + target[i].solidarea.y;
            	
            	
                switch (entity.direction) {
                    case "up":entity.solidarea.y -= entity.speed; break;
                    case "down":entity.solidarea.y += entity.speed;break;
                    case "left": entity.solidarea.x -= entity.speed;break;
                    case "right": entity.solidarea.x += entity.speed; break;
				}
				if (entity.solidarea.intersects(target[i].solidarea)) {
					if (target[i] != entity) {
					entity.collisionon = true;
					index = i;
					}
				}
                // Đặt lại tọa độ gốc của solidArea
                entity.solidarea.x = entity.solidAreaDefaultx;
                entity.solidarea.y = entity.solidAreaDefaulty;
                target[i].solidarea.x = target[i].solidAreaDefaultx;
                target[i].solidarea.y = target[i].solidAreaDefaulty;
            }
        }
        return index;
    }
    public boolean checkPlayer(Entity entity) {
    	
    	boolean contactPlayer = false;
    	
    	//Get entity's soild area position
    	entity.solidarea.x = entity.worldx + entity.solidarea.x;
    	entity.solidarea.y = entity.worldy + entity.solidarea.y;
    	//Get the object'ssolid area position
    	gp.player.solidarea.x = gp.player.worldx + gp.player.solidarea.x;
    	gp.player.solidarea.y = gp.player.worldy + gp.player.solidarea.y;
    	
    	
        switch (entity.direction) {
            case "up": entity.solidarea.y -= entity.speed;break;
            case "down":entity.solidarea.y += entity.speed;break;
            case "left":entity.solidarea.x -= entity.speed;break;
            case "right": entity.solidarea.x += entity.speed; break;
        }
    	if (entity.solidarea.intersects(gp.player.solidarea)) {
    		entity.collisionon = true;
    		contactPlayer = true;
    }

        // Đặt lại tọa độ gốc của solidArea
        entity.solidarea.x = entity.solidAreaDefaultx;
        entity.solidarea.y = entity.solidAreaDefaulty;
        gp.player.solidarea.x = gp.player.solidAreaDefaultx;
        gp.player.solidarea.y = gp.player.solidAreaDefaulty;
        
        return contactPlayer;
    }
    
}
