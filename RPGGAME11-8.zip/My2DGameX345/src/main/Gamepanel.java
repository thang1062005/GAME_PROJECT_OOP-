package main;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.swing.JPanel;

import entity.Entity;
import entity.Player;
import tile.Tilemanager;

public class Gamepanel extends JPanel implements Runnable {
	// CHỈNH MÀN HÌNH
	final int originaltilesize = 16; //16x16: NHÂN VẬT - NPC - Ô TILE TRÊN MAP
	final int scale = 3; //16x16 look like 48x48 
	public final int tilesize = originaltilesize*scale;
	public final int maxscreencol = 16;
	public final int maxscreenrow = 12;
	
	public final int screenwidth = tilesize*maxscreencol;// 768
	public final int screenheight = tilesize*maxscreenrow;//576
	
	
	//world setting
	public final int maxworldcol = 50;
	public final int maxworldrow = 50;

	int FPS = 60;
	
	//SYSTEM
	Tilemanager tileM = new Tilemanager(this);
	public Keyhandler keyH = new Keyhandler(this);
	Sound music = new Sound();
	Sound se = new Sound();
	public Collisioncheck ccheck = new Collisioncheck(this);
	public AssetSetter aSetter = new AssetSetter(this);
	public UI ui = new UI(this);
	public EventHandler eHandler = new EventHandler(this);
	Thread gameThread; //keep runing util u stop

	//ENTITY AND OBJECT
	public Player player = new Player(this, keyH);
	public Entity obj[] =  new Entity[10];
	public Entity npc[] = new Entity[10];
	public Entity monster[] = new Entity[20];
	public ArrayList<Entity> projectilelist = new ArrayList<>();
	ArrayList<Entity> entityList = new ArrayList<>();
	
	//GAME STATE
	public int gameState;
	public final int titleState = 0;
	public final int playState = 1;
	public final int pauseState = 2;
	public final int dialogueState = 3;
	public final int characterState = 4;
	
	
	
	// CONSTRUCTOR
	public Gamepanel() {
		this.setPreferredSize(new Dimension(screenwidth,screenheight));
		this.setBackground(Color.white);
		this.setDoubleBuffered(true); // all the drawing from this componet done offscreen
		this.addKeyListener(this.keyH); // có
		this.setFocusable(true);// có
		this.requestFocusInWindow();
	
	}
	
	public void setupGame () {
		aSetter.setObject();
		aSetter.setNPC();
		aSetter.setMonster();
		//playMusic(0);
		gameState = titleState;
		
	}
	
	public void startgamethread() {
		this.gameThread = new Thread(this); // gắn biển gameThread bằng 1 giá trị Thread lấy gamepanel là tham số
		this.gameThread.start();
	}
	
	//game loop
	public void run() {
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lasttime = System.nanoTime();
		long currenttime;
		long timer = 0;
		int drawcount = 0;
		while (gameThread != null) {
			currenttime =  System.nanoTime();
			delta += (currenttime-lasttime)/drawInterval;
			timer += (currenttime-lasttime);
			lasttime= currenttime ;
			if (delta >=1) {
				update();
				repaint();
				delta --;
				drawcount ++;
			}
			if (timer>= 1000000000) {
				
				drawcount = 0;
				timer=0;
			}
		
			
		}
		// TODO Auto-generated method stub
		
	}
	public void update() {
		
		if(gameState == playState) {
			//PLAYER
			player.update();
			//NPC
			for(int i = 0; i < npc.length; i++) {
				if(npc[i] != null) {
					npc[i].update();
				}
			}
			for(int i = 0; i < monster.length; i++) {
				if(monster[i] != null) {
					if(monster[i].alive == true && monster[i].dying == false) {
						monster[i].update();
					}
					if(monster[i].alive == false) {
						monster[i] = null;
					}
				}
			}
			for(int i = 0; i < projectilelist.size(); i++) {
				if(projectilelist.get(i) != null) {
					if(projectilelist.get(i).alive == true ) {
						projectilelist.get(i).update();
					}
					if(projectilelist.get(i).alive == false) {
						projectilelist.remove(i);
					}
				}
			}
		}
		if(gameState == pauseState) {
			
		}

	}
	
	// vẽ đồ họa tùy chỉnh lên JPanel bằng cách ghi đè phương thức
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		// khởi tạo g2, với Graphics2D là lớp con của g
		Graphics2D g2 = (Graphics2D)g;
		tileM.draw(g2); //layer of tile first
		
		//DEBUG
		long drawStart = 0;
		if(keyH.showDebugText == true) {
			drawStart = System.nanoTime();
		}
		
		// TITLE SCREEN
		if (gameState == titleState) {
		    ui.draw(g2);
		}
		// OTHERS
		else {
			// TILE
			tileM.draw(g2);
			// ADD ENTITY TO THE LIST
			entityList.add(player);
			for (int i =0; i< npc.length; i++) {
				if (npc[i] != null) {
					entityList.add(npc[i]);
				}
			}
			for (int i = 0; i < obj.length; i++) {
				if(obj[i] != null) {
					entityList.add(obj[i]);
				}
			}
			for (int i = 0; i < monster.length; i++) {
				if(monster[i] != null) {
					entityList.add(monster[i]);
				}
			}
			for (int i = 0; i < projectilelist.size(); i++) {
				if(projectilelist.get(i) != null) {
					entityList.add(projectilelist.get(i));
				}
			}
			
			
			// SORT
			Collections.sort(entityList, new Comparator<Entity>() {
				public int compare(Entity e1,Entity e2) {
					int result = Integer.compare(e1.worldy, e2.worldy);
					return result;
				}
			});
			//DRAW ENTITY
			for (int i = 0; i < entityList.size(); i++) {
				entityList.get(i).draw(g2);
			}
			//EMPTY ENTITY LIST
			entityList.clear();
			
			//UI 
			ui.draw(g2);
		}
		
		
		
		//DEBUG
		if(keyH.showDebugText == true) {
			long drawEnd = System.nanoTime();
			long passed = drawEnd - drawStart;
			
			g2.setFont(new Font("Arial",Font.PLAIN,20));
			g2.setColor(Color.white);
			int x = 10;
			int y = 400;
			int lineheight = 20;
			g2.drawString("WorldX"+ player.worldx , x, y);
			y+= lineheight;
			g2.drawString("WorldY"+ player.worldy , x, y);
			g2.drawString("Col"+ (player.worldx+player.solidarea.x) , x, y);
			g2.drawString("Row"+ (player.worldy+player.solidarea.y) , x, y);
			g2.drawString("Draw time: " + passed, x, y);
			System.out.println("Draw time:" + passed);
		}
		
		g2.dispose();
		}
	
	public void playMusic(int i) {
		music.setFile(i);
		music.play();
		music.loop();
	}
	
	public void stopMusic() {
		music.stop();
	}
	
	public void playSE(int i) {
		se.setFile(i);
		se.play();
	}

}
