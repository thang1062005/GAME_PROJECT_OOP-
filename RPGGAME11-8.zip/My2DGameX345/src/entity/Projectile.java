package entity;

import main.Gamepanel;

public class Projectile extends Entity {
	Entity user;

	public Projectile(Gamepanel gp) {
		super(gp);
		// TODO Auto-generated constructor stub
	}
	public void set(int worldX, int worldY, String direction,boolean alive,Entity user) {
		this.worldx = worldX;
		this.worldy= worldY;
		this.alive = alive;
		this.user = user;
		this.life = this.maxLife;
	}
	public void update() {
		if (user== gp.player) {
			int monsterIndex= gp.ccheck.checkEntity(this, gp.monster);
			if (monsterIndex !=999) {
				gp.player.damageMonster(monsterIndex,attack);
				alive = false;
			}
		}
		if (user!= gp.player) {
			
		}
		switch(direction) {
		case"up": worldy -= speed; break;
		case"down": worldy += speed; break;
		case "left": worldx -= speed; break;
		case "right": worldx += speed; break;
		}
		life--;
		if (life <=0) {
			alive = false;
		}
		spritecounter++;
		if (spritecounter>12) {
			if (spritenum==1) {
				spritenum =2;
			}
			else if (spritenum==2) {
				spritenum = 1;
				
			}
			spritecounter = 0;
		}
		
		
	}

}
