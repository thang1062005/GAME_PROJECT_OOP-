package entity;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.Gamepanel;
import main.UtilityTool;

// parent class
public class Entity {
	
	Gamepanel gp;
	public BufferedImage up1,up2,down1, down2, left1, left2, right1,right2;
	public BufferedImage attackUp1, attackUp2, attackDown1, attackDown2, attackLeft1, attackLeft2, attackRight1, attackRight2;
    public BufferedImage image, image2, image3;
    public Rectangle solidarea = new Rectangle(0, 0, 48, 48);
    public Rectangle attackArea = new Rectangle(0, 0, 0, 0);
    public int solidAreaDefaultx, solidAreaDefaulty ;
    public boolean collisionon = false;
    String dialogues[] = new String[20];


	public int x,y;
	//STATE
	public int worldx, worldy;
    public String direction = "down";
    public int spritenum = 1;
    int dialogueIndex = 0;
    public boolean collision = false;
    public boolean invincible = false;
    boolean attacking = false;
    public boolean alive = true;
    public boolean dying = false;
    boolean hpBarOn = false;



    //COUNTER
    public int actionLock = 0;
    public int invincibleCounter = 0;
    public int spritecounter =0;
    int dyingCounter = 0;
    int hpBarCounter = 0;

    
    // CHARACTER STATUS
    
    public String name;
	public int speed;
    public int maxLife;
    public int life;
    public int maxMana;
    public int level;
    public int strength;
    public int dexterity;
    public int attack;
    public int defense;
    public int exp;
    public int nextLevelExp;
    public int coin;
    public Entity currentWeapon;
    public Entity currentShield;
    public Projectile projectile;
    
    //Item attributes
    public int attackValue;
    public int defenseValue;
    public String description = "";
    public int useCost;
    // Loại
    public int type; // 0 =player, 1 =npc, 2 = monster
    public final int type_player = 0;
    public final int type_npc = 1;
    public final int type_monster = 2;
    public final int type_sword = 3;
    public final int type_axe = 4;
    public final int type_shield = 5;
    public final int type_consumable = 6;
    
    
    public Entity(Gamepanel gp) {
    	this.gp = gp;
    }
    
    public void setAction() {}
    
    public void damageReaction() {}
    
    public void speak() {
    	
    	if (dialogues[dialogueIndex] == null) {
		    dialogueIndex = 0;
		}
		gp.ui.currentDialogue = dialogues[dialogueIndex];
		dialogueIndex++;
		
		switch (gp.player.direction) {
	    case "up":
	        direction = "down";
	        break;
	    case "down":
	        direction = "up";
	        break;
	    case "left":
	        direction = "right";
	        break;
	    case "right":
	        direction = "left";
	        break;

		}
    	
    }
    public void use(Entity entity) {
    	
    	
    }
    public void update() {
    	setAction();
    	collisionon = false;
    	gp.ccheck.CheckTile(this);
    	gp.ccheck.CheckObject(this, false);
    	gp.ccheck.checkEntity(this, gp.npc);
    	gp.ccheck.checkEntity(this, gp.monster);
    	boolean contactPlayer = gp.ccheck.checkPlayer(this);
    	
    	if (this.type == 2 && contactPlayer == true) {
    		if (gp.player.invincible == false) {
    			//we can give damage
    			gp.playSE(6);

    			int damage = attack - gp.player.defense;
				if(damage < 0) {
					damage = 0;
				}
				
				gp.player.life -= damage;
    			gp.player.invincible = true;
    		}
    	}
    	
    	if (!collisionon) {
            switch (direction) {
                case "up": worldy -= speed; break;
                case "down": worldy += speed; break;
                case "left": worldx -= speed; break;
                case "right": worldx += speed; break;
            }
        }

        // Điều khiển sprite animation
        spritecounter++;
        if (spritecounter > 15) {
            if (spritenum == 1) {
                spritenum = 2;
            } else if (spritenum == 2) {
                spritenum = 1;
            }
            spritecounter = 0;
        }
        
        if (invincible == true) {
	    	invincibleCounter++;
	    	if(invincibleCounter > 40) {
	    		invincible = false;
	    		invincibleCounter = 0;
	    	}
	    }
    }
    
    public void draw(Graphics2D g2) {
    	BufferedImage image = null;
    	int screenx = worldx - gp.player.worldx + gp.player.screenx;
        int screeny = worldy - gp.player.worldy + gp.player.screeny;

        if(worldx + gp.tilesize > gp.player.worldx - gp.player.screenx &&
           worldx - gp.tilesize < gp.player.worldx + gp.player.screenx &&
           worldy + gp.tilesize > gp.player.worldy - gp.player.screeny &&
           worldy - gp.tilesize < gp.player.worldy + gp.player.screeny) {
        	
        	switch (direction) {
    		case "up":
    			if (spritenum ==1) {image = up1;}
    			if (spritenum ==2) {image = up2;}
    			break;
    		case "down":
    			if (spritenum ==1) {image = down1;}
    			if (spritenum ==2) {image = down2;}
    			break;
    		case "left":
    			if (spritenum ==1) {image = left1;}
    			if (spritenum ==2) {image = left2;}
    			break;
    		case "right":
    			if (spritenum ==1) {image = right1;}
    			if (spritenum ==2) {image = right2;}
    			break;
    		}
        	
        	//Monster HP bar
        	if(type == 2 && hpBarOn == true) {
        		double oneScale = (double)gp.tilesize/maxLife;
        		double hpBarValue = oneScale*life;
        		
        		
        		g2.setColor(new Color(35, 35, 35));
            	g2.fillRect(screenx - 1, screeny - 16, gp.tilesize + 2, 12);
        		
        		g2.setColor(new Color(255,0, 30));
            	g2.fillRect(screenx, screeny - 15, (int)hpBarValue, 10);
            	
            	hpBarCounter++;
            	
            	if(hpBarCounter > 600) {
            		hpBarCounter = 0;
            		hpBarOn = false;
            	}
        	}
        	
        	if(invincible == true) {
        		hpBarOn = true;
        		hpBarCounter = 0;
        		changeAlpha(g2, 0.4F);
        		
        	}
        	if(dying == true) {
        		dyingAnimation(g2); 
        	}

            g2.drawImage(image, screenx, screeny, gp.tilesize, gp.tilesize, null);
            
            changeAlpha(g2, 1F);
        }
    }
    
    public void dyingAnimation(Graphics2D g2) {
    	dyingCounter++;
    	
    	int i = 10;
    	
    	if(dyingCounter <= i) {changeAlpha(g2, 0f);}
    	if(dyingCounter > i && dyingCounter <= i*2) {changeAlpha(g2, 1f);}
    	if(dyingCounter > i*2 && dyingCounter <= i*3) {changeAlpha(g2, 0f);}
    	if(dyingCounter > i*3 && dyingCounter <= i*4) {changeAlpha(g2, 1f);}
    	if(dyingCounter > i*4 && dyingCounter <= i*5) {changeAlpha(g2, 0f);}
    	if(dyingCounter > i*5 && dyingCounter <= i*6) {changeAlpha(g2, 1f);}
    	if(dyingCounter > i*6 && dyingCounter <= i*7) {changeAlpha(g2, 0f);}
    	if(dyingCounter > i*7 && dyingCounter <= i*8) {changeAlpha(g2, 1f);}
    	if(dyingCounter > i*8) {
  
    		alive = false;
    	}
    }
    
    public void changeAlpha(Graphics2D g2, float alphaValue) {
    	g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alphaValue));
    }
    
    public BufferedImage setup(String imagePath, int width, int height) {
		UtilityTool uTool = new UtilityTool();
		BufferedImage image = null;
		try {
			image = ImageIO.read(getClass().getResourceAsStream(imagePath + ".png"));
			image = uTool.scaledImage(image, width, height);
		} catch(IOException e) {
			e.printStackTrace();
		}
		return image;
	}
}    
