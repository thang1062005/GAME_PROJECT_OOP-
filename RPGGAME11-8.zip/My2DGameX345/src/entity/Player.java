package entity;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import main.Gamepanel;
import main.Keyhandler;
import object.OBJ_Fireball;
import object.OBJ_Key;
import object.OBJ_Shield_Wood;
import object.OBJ_Sword_Normal;

public class Player extends Entity {

	Keyhandler keyH;
	public final int screenx; // position of camera
	public final int screeny;
	int standCounter = 0;
	public boolean attackCancel = false;
	public ArrayList<Entity> inventory = new ArrayList<>();
	public final int maxinventorySize = 20;
	
	public Player(Gamepanel gp, Keyhandler keyH ) {
		super(gp);
		this.keyH = keyH;
		
		// screenwidth là độ rộng màn hình
		// screenheight là độ cao màn hình
		screenx = gp.screenwidth/2-(gp.tilesize/2);
		screeny = gp.screenheight/2-(gp.tilesize/2);
		
		
		solidarea = new Rectangle();
		solidarea.x = 8;
		solidarea.y = 16;
		
		solidAreaDefaultx =solidarea.x; // default, vì sẽ thay đổi solidareax sau
		solidAreaDefaulty = solidarea.y;
		
		solidarea.width = 32;
		solidarea.height = 32;
		
		
//		attackArea.width = 36;
//		attackArea.height = 36;
		
		setdefaultval();
		getPlayerImage();
		getPlayerAttackImage();
		setItems();
	}
	
	public void setdefaultval() {
		worldx = gp.tilesize*23; // toa do bat dau
		worldy = gp.tilesize*21;// the starting position
//		worldx = gp.tilesize*10;
//		worldy = gp.tilesize*13;
		speed = 4;
		direction= "down";
		
		// PLAYER STATUS
		level = 1;
		maxLife = 6;
		life = maxLife;
		strength = 1; //More strength, more damage causes
		dexterity = 1; //More dexterity, less damage gives
		exp = 0;
		nextLevelExp = 5;
		coin  = 0;
		currentWeapon = new OBJ_Sword_Normal(gp);
		currentShield = new OBJ_Shield_Wood(gp);
		projectile = new OBJ_Fireball(gp);
		attack = getAttack();    //Total attack is decided by strength and weapon
		defense = getDefense();  //Total defense is decided by dexterity and shield
	}
	public void setItems() { // them đồ vào coursor
		inventory.add(currentWeapon);
		inventory.add(currentShield);
		inventory.add(new OBJ_Key(gp));
		
		
		
	}
	public int getAttack() {
		attackArea = currentWeapon.attackArea;
		return attack = strength * currentWeapon.attackValue;
	}
	
	public int getDefense() {
		return defense = dexterity * currentShield.defenseValue;
	}
	
	public void getPlayerImage() {
	    up1 = setup("/player/boy_up_1", gp.tilesize, gp.tilesize);
	    up2 = setup("/player/boy_up_2", gp.tilesize, gp.tilesize);
	    down1 = setup("/player/boy_down_1", gp.tilesize, gp.tilesize);
	    down2 = setup("/player/boy_down_2", gp.tilesize, gp.tilesize);
	    left1 = setup("/player/boy_left_1", gp.tilesize, gp.tilesize);
	    left2 = setup("/player/boy_left_2", gp.tilesize, gp.tilesize);
	    right1 = setup("/player/boy_right_1", gp.tilesize, gp.tilesize);
	    right2 = setup("/player/boy_right_2", gp.tilesize, gp.tilesize);
	}

	public void getPlayerAttackImage() {
		if (currentWeapon.type== type_sword||currentWeapon.type==type_axe) {
	    attackUp1 = setup("/player/boy_attack_up_1", gp.tilesize, gp.tilesize*2);
	    attackUp2 = setup("/player/boy_attack_up_2", gp.tilesize, gp.tilesize*2);
	    attackDown1 = setup("/player/boy_attack_down_1", gp.tilesize, gp.tilesize*2);
	    attackDown2 = setup("/player/boy_attack_down_2", gp.tilesize, gp.tilesize*2);
	    attackLeft1 = setup("/player/boy_attack_left_1", gp.tilesize*2, gp.tilesize);
	    attackLeft2 = setup("/player/boy_attack_left_2", gp.tilesize*2, gp.tilesize);
	    attackRight1 = setup("/player/boy_attack_right_1", gp.tilesize*2, gp.tilesize);
	    attackRight2 = setup("/player/boy_attack_right_2", gp.tilesize*2, gp.tilesize);
		}
		
		
		
	}
	
	// update method get call 60times per sec
	public void update() {
		if (attacking == true) {
			attacking();
		}
		else if (keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true || keyH.enterPressed == true) {
	        // Xác định hướng di chuyển dựa vào các phím điều khiển
	        if (keyH.upPressed) {
	            direction = "up";
	        } else if (keyH.downPressed) {
	            direction = "down";
	        } else if (keyH.leftPressed) {
	            direction = "left";
	        } else if (keyH.rightPressed) {
	            direction = "right";
	        }

	        // Kiểm tra va chạm với tiles
	        collisionon = false;
	        gp.ccheck.CheckTile(this);

	        // Kiểm tra va chạm với đối tượng và thực hiện nhặt đồ
	        int objectIndex = gp.ccheck.CheckObject(this, true);
	        pickUpObject(objectIndex);
	        
	        //CHECK NPC COLLISION
	        int npcIndex = gp.ccheck.checkEntity(this, gp.npc);
	        interactNPC(npcIndex);
	        
	        //CHECK MONSTER COLLISION
	        int monsterIndex = gp.ccheck.checkEntity(this, gp.monster);
	        contactMonster(monsterIndex);
	        
	        // CHECK EVENT
	        gp.eHandler.checkEvent();
	        

	        // Nếu không có va chạm, người chơi có thể di chuyển
	        if (collisionon == false && keyH.enterPressed == false) {
	            switch (direction) {
	                case "up": worldy -= speed; break;
	                case "down": worldy += speed; break;
	                case "left": worldx -= speed; break;
	                case "right": worldx += speed; break;
	            }
	        }
	        
	        if(keyH.enterPressed == true && attackCancel == false) {
	        	gp.playSE(7);
	        	attacking = true;
	        	spritecounter = 0;
	        }
	        
	        attackCancel = false;
			gp.keyH.enterPressed = false;


	        // Điều khiển sprite animation
	        spritecounter++;
	        if (spritecounter > 15) {
	            if (spritenum == 1) {
	                spritenum = 2;
	            } else if (spritenum == 2) {
	                spritenum = 1;
	            }
	            spritecounter = 0;
	        }
	    } else {
	    	standCounter++;
	    	if(standCounter == 20) {
	    		spritenum = 1;
	    		standCounter = 0;
	    	}
	    }
		if (gp.keyH.shotPressed== true && projectile.alive==false) {
			// đặt tọa độ mặc định
			projectile.set(worldx, worldy,direction, true,this);
			// thêm vào danh sách
			gp.projectilelist.add(projectile);
			gp.playSE(5);
			
		}
		
	    //This needs to be outside of key if atatement!
	    if (invincible == true) {
	    	invincibleCounter++;
	    	if(invincibleCounter > 60) {
	    		invincible = false;
	    		invincibleCounter = 0;
	    	}
	    }
	}

	public void attacking() {
	    spritecounter++;

	    if (spritecounter <= 5) {
	        spritenum = 1;
	    }
	    if (spritecounter > 5 && spritecounter <= 25) {
	        spritenum = 2;
	        
	        //Save the current worldX/Y, solidarea
	        int currentWorldX = worldx;
	        int currentWorldY = worldy;
	        int solidAreaWidth = solidarea.width;
	        int solidAreaHeight = solidarea.height;
	        
	        //Adjust player's world for attackArea
	        switch(direction) {
	        case "up": worldy -= attackArea.height; break;
	        case "down": worldx += attackArea.height; break;
	        case "left": worldx -= attackArea.width; break;
	        case "right": worldy += attackArea.width; break;
	        }
	        //attackArea become solidArea
	        solidarea.width = attackArea.width;
	        solidarea.height = attackArea.height;
	        //check monster collision with the updated worldX/Y and solidArea
	        int monsterIndex = gp.ccheck.checkEntity(this, gp.monster);
	        damageMonster(monsterIndex,attack);
	        
	        worldx = currentWorldX;
	        worldy = currentWorldY;
	        solidarea.width = solidAreaWidth;
	        solidarea.height = solidAreaHeight;     
	    }
	    if (spritecounter > 25) {
	        spritenum = 1;
	        spritecounter = 0;
	        attacking = false;
	    }
	}

	public void pickUpObject(int i) {
	    if (i != 999) {
	    	String text;
	        if (inventory.size()!=maxinventorySize) {
	        	inventory.add(gp.obj[i]);
	        	gp.playSE(1);
	        	text = "Got a "+ gp.obj[i].name + "!";
	        	
	        }
	        else {
	        	text = "Cant carry more!";
	        }
	        gp.ui.addMessage(text);
	        gp.obj[i]= null;
	    }
	}

	public void interactNPC(int i) {
		if (gp.keyH.enterPressed == true) {
			if(i != 999) {
				attackCancel = true;
				gp.gameState = gp.dialogueState;
				gp.npc[i].speak();
			}
			
		}
	}

	public void contactMonster(int i ) {
		if ( i != 999) {
			if (invincible == false && gp.monster[i].dying == false) {
				gp.playSE(6);
				
				int damage = gp.monster[i].attack - defense;
				if(damage < 0) {
					damage = 0;
				}
				
				life -= damage;
				invincible = true;
			}			
		}
	}
	
	public void damageMonster(int i, int attack) {
		if(i != 999) {
			if (gp.monster[i].invincible == false) {
				gp.playSE(5);
				
				int damage = attack - gp.monster[i].defense;
				if(damage < 0) {
					damage = 0;
				}
				
				gp.monster[i].life -= damage;
				gp.ui.addMessage(damage + "damage!");
				
				gp.monster[i].invincible = true;
				gp.monster[i].damageReaction();
				
				if (gp.monster[i].life <= 0) {
					gp.monster[i].dying = true;
					gp.ui.addMessage("Killed the " + gp.monster[i].name + "!");
					gp.ui.addMessage("Exp " + gp.monster[i].exp);
					exp += gp.monster[i].exp;
					checkLevelUp();
				}
			}
		}
	}
	
	public void checkLevelUp() {
		if(exp >= nextLevelExp) {
			level++;
			nextLevelExp = nextLevelExp * 2;
			maxLife += 2;
			strength++;
			dexterity++;
			attack = getAttack();
			defense = getDefense();
			
			gp.playSE(8);
			gp.gameState = gp.dialogueState;
			gp.ui.currentDialogue = "You are level" + level + " now!\nYou feel stronger!";
		}
	}
	public void selectItem() {
		int itemIndex = gp.ui.getItemIndexOnSlot();
		if (itemIndex < inventory.size()) {
			Entity selectedItem = inventory.get(itemIndex);
			if (selectedItem.type== type_sword || selectedItem.type == type_axe) {
				currentWeapon= selectedItem;
				attack = getAttack();
				getPlayerAttackImage();
			}
			if (selectedItem.type== type_shield) {
				currentShield = selectedItem;
				defense = getDefense();
				
			}
			if (selectedItem.type == type_consumable) {
				selectedItem.use(this);
				inventory.remove(itemIndex);
				
				
			}
		}
	}
	public void draw(Graphics2D g2) {
		g2.setColor(new Color(0,0,0,0));
		g2.fillRect(x, y, gp.tilesize, gp.tilesize);
		BufferedImage image = null;
		int tempScreenX = screenx;
		int tempScreenY = screeny;
		
		switch(direction) {
	    case "up":
	        if (attacking == false) {
	            if (spritenum == 1) { image = up1; }
	            if (spritenum == 2) { image = up2; }
	        }
	        if (attacking == true) {
	        	tempScreenY = screeny - gp.tilesize;
	            if (spritenum == 1) { image = attackUp1; }
	            if (spritenum == 2) { image = attackUp2; }
	        }
	        break;
	    case "down":
	        if (attacking == false) {
	            if (spritenum == 1) { image = down1; }
	            if (spritenum == 2) { image = down2; }
	        }
	        if (attacking == true) {
	            if (spritenum == 1) { image = attackDown1; }
	            if (spritenum == 2) { image = attackDown2; }
	        }
	        break;
	    case "left":
	        if (attacking == false) {
	            if (spritenum == 1) { image = left1; }
	            if (spritenum == 2) { image = left2; }
	        }
	        if (attacking == true) {
	        	tempScreenX = screenx - gp.tilesize;
	            if (spritenum == 1) { image = attackLeft1; }
	            if (spritenum == 2) { image = attackLeft2; }
	        
	        }
	        break;
	    case "right":
	        if (attacking == false) {
	            if (spritenum == 1) { image = right1; }
	            if (spritenum == 2) { image = right2; }
	        }
	        if (attacking == true) {
	            if (spritenum == 1) { image = attackRight1; }
	            if (spritenum == 2) { image = attackRight2; }
	        
	        }
	        break;
	}

		if (invincible == true) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
		}
		
		
		g2.drawImage(image, tempScreenX, tempScreenY,null);
		//RESET ALPHA
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		//DEBUG
//		g2.setFont(new Font("Arial", Font.PLAIN,26));
//		g2.setColor(Color.white);
//		g2.drawString("Invincible:"+invincibleCounter, 10, 400);
	}

}